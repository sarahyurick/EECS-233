// Sarah Yurick
// sey13
import java.util.Stack;

public class WeightedGraph implements Cloneable
{
   private double[ ][ ] edges;
   private Object[ ] labels;
   
   public WeightedGraph(int n)
   {
      edges = new double[n][n];  // All values initially null
      for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
          edges[i][j] = -1.0;
        }
      }
      labels = new Object[n];     // All values initially null
   }
   
   public void addEdge(int source, int target, double weight)   
   {
      edges[source][target] = weight;
   }
   
   public double getWeight(int source, int target) {
     return edges[source][target];
   }
   
   public void printTotalPath(int[] path) {
     double sum = 0.0;
     boolean validPath = true;
     for(int i = 0; i < path.length - 1; i++) {
       if(isEdge(path[i], path[i + 1])) {
         sum += getWeight(path[i], path[i + 1]);
       } else {
         validPath = false;
       }
     }
    
     String line = "The path from ";
     for(int i = 0; i < path.length; i++) {
       line += labels[path[i]] + " ";
       if(i != path.length - 1) {
         line += "to ";
       }
     }
     if(validPath) {
       line += "has a total of " + sum + ".";
     } else {
       line += "is not valid.";
     }
     System.out.println(line);
   }
   
   public Object getLabel(int vertex)
   {
      return labels[vertex];
   }

   public boolean isEdge(int source, int target)
   {
      return (edges[source][target] != -1.0);
   }
   
   public int[ ] neighbors(int vertex)
   {
      int i;
      int count;
      int[ ] answer;
      
      // First count how many edges have the vertex as their source
      count = 0;
      for (i = 0; i < labels.length; i++)
      {
         if (edges[vertex][i] > -1.0)
            count++;
      }
           
      // Allocate the array for the answer
      answer = new int[count];
      
      // Fill the array for the answer
      count = 0;
      for (i = 0; i < labels.length; i++)
      {
         if (edges[vertex][i] > -1.0)
            answer[count++] = i;
      }
      
      return answer;
   }
              
   public void removeEdge(int source, int target)   
   {
      edges[source][target] = -1.0;
   }

   public void setLabel(int vertex, Object newLabel)
   {
      labels[vertex] = newLabel;
   }   
   
   public int size( )
   {
      return labels.length;
   }
   
   // part a
   public void dijkstra(int start, int target) {
     double infinity = Double.POSITIVE_INFINITY;
     int originalStart = start;
     int n = labels.length;
     int allowedSize;
     int v;
     double sum;
     int[] predecessor = new int[n];
     
     double[] distances = new double[n];
     for(int i = 0; i < n; i++) {
       distances[i] = infinity;
     }
     distances[start] = 0;
     
     boolean[] allowedVertices = new boolean[n];
     
     String allowedStr = "allowed: ";
     String distanceStr = "distance: ";
     for(int i = 0; i < n; i++) {
       allowedStr += allowedVertices[i] + " ";
       distanceStr += distances[i] + " ";
     }
     System.out.println("Initial values...");
     System.out.println(allowedStr);
     System.out.println(distanceStr);
     System.out.println("******************************************");
     System.out.println("Executing loop...");
     
     for(allowedSize = 1; allowedSize < n; allowedSize++) {
       int next = start;
       double smallest = infinity;
       for(int i = 0; i < n; i++) {
         if(smallest > distances[i] && !allowedVertices[i]) {
           smallest = distances[i];
           next = i;
         }
       }
       
       allowedVertices[next] = true;
       for(v = 0; v < n; v++) {
         if(!allowedVertices[v] && isEdge(next, v)) {
           sum = distances[next] + edges[next][v];
           if(sum < distances[v]) {
             distances[v] = sum;
             predecessor[v] = next;
           }
         }
       }
       
       // part b
       allowedStr = "allowed: ";
       distanceStr = "distance: ";
       for(int i = 0; i < n; i++) {
         allowedStr += allowedVertices[i] + " ";
         distanceStr += distances[i] + " ";
       }
       System.out.println(allowedStr);
       System.out.println(distanceStr);
       System.out.println("******************************************");
     }
     
     // part c
     if(distances[target] == infinity) {
       System.out.println("There is no path from " + start + " to " + target + ".");
     } else {
       String line = "Shortest path: ";
       Stack stack = new Stack();
       int vertexOnPath = target;
       stack.push(vertexOnPath);
       while(vertexOnPath != start) {
         vertexOnPath = predecessor[vertexOnPath];
         stack.push(vertexOnPath);
       }
       while(!stack.isEmpty()) {
         line += stack.pop() + " ";
       }
       System.out.println(line);
     }
   }
   
   // part d
   public static void main(String[] args) {
     WeightedGraph g = new WeightedGraph(6);
     g.addEdge(0, 1, 2.);
     g.addEdge(0, 5, 9.);
     g.addEdge(1, 5, 6.);
     g.addEdge(1, 2, 8.);
     g.addEdge(1, 3, 15.);
     g.addEdge(2, 3, 1.);
     g.addEdge(4, 3, 3.);
     g.addEdge(4, 2, 7.);
     g.addEdge(5, 4, 3.);
     
     g.setLabel(0, "v0");
     g.setLabel(1, "v1");
     g.setLabel(2, "v2");
     g.setLabel(3, "v3");
     g.setLabel(4, "v4");
     g.setLabel(5, "v5");
     
     g.dijkstra(0, 4);
     System.out.println();
     g.dijkstra(4, 0);
     
     // checking #4
     /* WeightedGraph g = new WeightedGraph(8);
     g.addEdge(1, 2, 2.);
     g.addEdge(2, 5, 4.);
     g.addEdge(3, 1, 1.);
     g.addEdge(1, 4, 5.);
     g.addEdge(2, 4, 1.);
     g.addEdge(4, 3, 8.);
     g.addEdge(4, 5, 1.);
     g.addEdge(3, 6, 9.);
     g.addEdge(4, 6, 7.);
     g.addEdge(4, 7, 7.);
     g.addEdge(5, 7, 2.);
     g.addEdge(7, 6, 1.);
     
     g.dijkstra(3, 6); */
   }
        
}
           
