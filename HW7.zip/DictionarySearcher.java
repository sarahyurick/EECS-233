// Sarah Yurick
// sey13

import java.util.*; // Provides Scanner
import java.io.*; // Provides FileReader, FileNotFoundException
import java.util.ArrayList;

public class DictionarySearcher
{
   public static void main(String[ ] args)
   {
     ArrayList<String> array1 = new ArrayList<String>();
     ArrayList<String> array2 = new ArrayList<String>();
     Scanner scanner;
     
     try {
       scanner = new Scanner(new FileReader("usa.txt"));
     }
     catch (FileNotFoundException e) {
       System.err.println(e);
       return;
     }
     
     while (scanner.hasNext()) {
       String word = scanner.next();
       // Remove all characters that aren't letters, and set to lowercase
       word = word.replaceAll("[^a-zA-Z ]", "").toLowerCase();
       array1.add(word);
     }
     // System.out.println(array1);
     
     try {
       scanner = new Scanner(new FileReader("text.txt"));
     }
     catch (FileNotFoundException e) {
       System.err.println(e);
       return;
     }
     
     while (scanner.hasNext()) {
       String word = scanner.next();
       // Remove all characters that aren't letters, and set to lowercase
       word = word.replaceAll("[^a-zA-Z ]", "").toLowerCase();
       array2.add(word);
     }
     // array2.add("");
     // System.out.println(array2);
     
     int sum = 0;
     for(int i = 0; i < array2.size(); i++)
     {
       if(search(array1, 0, array1.size(), array2.get(i)) == -1) {
         sum += 1;
       }
     }
     
     System.out.println(sum);
     // System.out.println(array1.size());
     // System.out.println(array2.size());
     
   }
 
        
   // Outputs the number of words in the 2nd text file
   // that do not appear in the dictionary.
   public static int search(ArrayList<String> a, int first, int size, String target)
   {
     int difference;
     int mid;
     
     if (size <= 0) {
         return -1;
     }
      else
      {
        mid = first + size/2;
        difference = target.compareTo(a.get(mid));
        if(difference == 0) {
          return mid;
        } else if (difference < 0) {
          return search(a, first, size/2, target);
        } else {
          return search(a, mid+1, (size-1)/2, target);
        }
    }
   }
}
