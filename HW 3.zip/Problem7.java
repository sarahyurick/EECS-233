// Sarah Yurick
// sey13

import java.util.Queue;
import java.util.Scanner;
import java.util.LinkedList;

public class Problem7 {
   public static void main(String[ ] args)
   {
      Scanner stdin = new Scanner(System.in);
      boolean continuing = true;
      String catching;
      String name;
      int time;
      int lastEnteredTime = 0;
      double answer;
      
      Queue<String> names = new LinkedList<String>();
      Queue<Integer> times = new LinkedList<Integer>();
      
      System.out.print("Enter name (or quit): ");
      name = stdin.nextLine();

      while(continuing) {
        System.out.print("Enter current time: ");
        time = stdin.nextInt();
        if(time >= 2400) {
          System.out.println("Not a valid time!");
          break;
        }
        if(time > 2300 || lastEnteredTime >= 2400) {
          System.out.println(name + " cannot use it in this 24-hour period.");
          break;
        }
        
        try {
          names.add(name);
          if(times.isEmpty()) {
            int newTime = time + 100;
            times.add(newTime);
            lastEnteredTime = newTime;
          } else {
            int newTime;
            if(time <= (lastEnteredTime + 100)) {
              newTime = lastEnteredTime + 100;
            } else {
              newTime = time + 100;
            }
            times.add(newTime);
            lastEnteredTime = newTime;
          }
          
          while(true) {
            if(time >= times.peek()) {
              String donePerson = names.remove();
              times.remove();
              System.out.println(donePerson + " is done.");
            } else {
              break;
            }
          }
          
          if(names.peek().equals(name)) {
            System.out.println(name + " can have it now!");
          } else {
            System.out.println(name + " can have it at " + (lastEnteredTime - 100) + ".");
          }
          
        }
        catch (Exception e) {
          System.out.println("Error." + e.toString());
        }
        
        System.out.print("Enter name (or quit): ");
        catching = stdin.nextLine( );
        name = stdin.nextLine();
        if(name.equalsIgnoreCase("quit")) {
          continuing = false;
        }
      }
  
   } 
  
  
}