// Sarah Yurick (sey13)
import java.util.Scanner;

public class Problem1 {

    public static void main(String[] args) {
        Scanner stdin = new Scanner(System.in);
        String expression;
        
        System.out.println("Please type a string containing parentheses ( )");
        System.out.println("I'll check whether the parentheses are balanced.");
        
        do {
            System.out.println("Your string: ");
            expression = stdin.nextLine();
            if(isBalanced(expression)) {
                System.out.println("That is balanced.");
            } else {
                System.out.println("That is not balanced.");
            }
        }
        while(query(stdin, "Another string?"));
        
        System.out.println("Thanks for that balancing act.");
    }
    
    public static boolean isBalanced(String str) {
        int len = str.length();
        int numOpening = 0;

        for(int i = 0; i < len; i++) {
            if(str.charAt(i) == '(') {
                numOpening++;
            }
            if(str.charAt(i) == ')') {
                numOpening--;
                if(numOpening < 0) {
                    return false;
                }
            }
        }
        
        if(numOpening != 0) {
            return false;
        }
        
        return true;
    }
    
    public static boolean query(Scanner input, String prompt) {
        String answer;
 
        System.out.print(prompt + " [Y or N]: ");
        answer = input.nextLine( ).toUpperCase( );
        while (!answer.startsWith("Y") && !answer.startsWith("N")) {
            System.out.print("Invalid response. Please type Y or N: ");
            answer = input.nextLine( ).toUpperCase( );
        }

        return answer.startsWith("Y");
    }
    
}


