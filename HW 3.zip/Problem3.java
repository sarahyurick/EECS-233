// Sarah Yurick
// sey13

// Note that I also copy/pasted the code from IsBalancedDemonstration.java to check parentheses

import java.util.Stack;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Problem3
{
   
   public static void main(String[ ] args)
   {
      Scanner stdin = new Scanner(System.in);
      String str;
      double answer;
      
      System.out.println("Please type an arithmetic expression made from");
      System.out.println("unsigned numbers and the operations + - * /.");
      System.out.println("The expression must be fully parenthesized");
      System.out.println("in order to evaluate the result.");
      

      do
      {
         ArrayStack<Integer> arr = new ArrayStack<Integer>();
         LinkedStack<Character> ls = new LinkedStack<Character>();
      
         System.out.print("Your expression: ");
         str = stdin.nextLine( );
         System.out.println();
         try
         {
           if(!isBalanced(str)) {
             throw new IllegalArgumentException("Parentheses are not balanced");
           }
           for(int i = 0; i < str.length(); i++) {
             Character here = str.charAt(i);
             if(isNumber(here)) {
               int toPush = Character.getNumericValue(here);
               arr.push(toPush);
             } else if(isOperator(here)) {
               ls.push(here);
             } else if(here == ')') {
               if(arr.size() < 2 || ls.isEmpty()) {
                 throw new IllegalArgumentException("Illegal input expression");
               }
             
               int secondNum = arr.pop();
               int firstNum = arr.pop();
               Character task = ls.pop();
               
               if(task == '+') {
                 int result = firstNum + secondNum;
                 arr.push(result);
               }
               if(task == '-') {
                 int result = firstNum - secondNum;
                 arr.push(result);
               }
               if(task == '*') {
                 int result = firstNum * secondNum;
                 arr.push(result);
               }
               if(task == '/') {
                 if(secondNum == 0) {
                   throw new IllegalArgumentException("Illegal input expression");
                 }
                 int result = firstNum / secondNum;
                 arr.push(result);
               }
               
           } else if(here != '(' && here != ' ') {
               throw new IllegalArgumentException("Illegal input expression");
             }
             
             System.out.print("Character: " + here + "  ");
             System.out.print("\tNumbers= ");
             arr.print();
             System.out.print("  \tOperators= ");
             ls.print();
             
             if((i == (str.length() - 1)) && (isNumber(here) || isOperator(here)
                                                || arr.size() > 1 || ls.size() != 0)) {
               throw new IllegalArgumentException("Illegal input expression (Did you remember parentheses?)");
             }

           }

         }
         catch (Exception e) {
           System.out.println("Error." + e.toString( ));
         }
      }
      
      while (query(stdin, "Another string?"));
   }

     
   public static boolean query(Scanner input, String prompt)
   {
      String answer;
 
      System.out.println(prompt + " [Y or N]: ");
      answer = input.nextLine( ).toUpperCase( );
      while (!answer.startsWith("Y") && !answer.startsWith("N"))
      {
  System.out.println("Invalid response. Please type Y or N: ");
  answer = input.nextLine( ).toUpperCase( );
      }

      return answer.startsWith("Y");
   }
   
   public static boolean isOperator(Character c) {
     if(c == '+' || c == '-' || c == '*' || c == '/') {
       return true;
     }
     return false;
   }
   
   public static boolean isNumber(Character c) {
     if(c == '0' || c == '1' || c == '2' || c == '3' || c == '4'
          || c == '5' || c == '6' || c == '7' || c == '8' || c == '9') {
       return true;
     }
     return false;
   }
   
      public static boolean isBalanced(String expression)
   // Postcondition: A true return value indicates that the parentheses in the
   // given expression are balanced. Otherwise the return value is false.
   // Note that characters other than ( ) { } and [ ] are ignored.
   {
      // Meaningful names for characters
      final char LEFT_NORMAL  = '(';
      final char RIGHT_NORMAL = ')';
      final char LEFT_CURLY   = '{';
      final char RIGHT_CURLY  = '}';
      final char LEFT_SQUARE  = '[';
      final char RIGHT_SQUARE = ']';
      
      Stack<Character> store = new Stack<Character>( ); // Stores parens
      int i;                              // An index into the string
      boolean failed = false;             // Change to true for a mismatch
      
      for (i = 0; !failed && (i < expression.length( )); i++)
      {
         switch (expression.charAt(i))
         {
            case LEFT_NORMAL:
            case LEFT_CURLY:
            case LEFT_SQUARE: 
               store.push(expression.charAt(i));
               break;
            case RIGHT_NORMAL:
               if (store.isEmpty( ) || (store.pop( ) != LEFT_NORMAL))
                  failed = true;
               break;
            case RIGHT_CURLY:
               if (store.isEmpty( ) || (store.pop( ) != LEFT_CURLY))
                  failed = true;
               break;
            case RIGHT_SQUARE:
               if (store.isEmpty( ) || (store.pop( ) != LEFT_SQUARE))
                  failed = true;
               break;
         }
      }
      
      return (store.isEmpty( ) && !failed);
   }
     
}
