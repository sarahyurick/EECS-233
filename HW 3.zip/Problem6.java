// Sarah Yurick
// sey13

import java.util.Stack;
import java.util.Scanner;

public class Problem6
{

   public static void main(String[ ] args)
   {
      Scanner stdin = new Scanner(System.in);
      String str;
      double answer;

      do
      {
        System.out.print("Your expression: ");
         str = stdin.nextLine( );
         try
         {
           System.out.println("Result: " + evaluate(str));

         }
         catch (Exception e) {
           System.out.println("Error." + e.toString( ));
         }
      }
      
      while (query(stdin, "Another string?"));
   }

     
   public static boolean query(Scanner input, String prompt)
   {
      String answer;
      
      System.out.println();
      System.out.println(prompt + " [Y or N]: ");
      answer = input.nextLine( ).toUpperCase( );
      while (!answer.startsWith("Y") && !answer.startsWith("N"))
      {
  System.out.println("Invalid response. Please type Y or N: ");
  answer = input.nextLine( ).toUpperCase( );
      }

      return answer.startsWith("Y");
   }
   
   public static boolean isOperator(Character c) {
     if(c == '+' || c == '-' || c == '*' || c == '/') {
       return true;
     }
     return false;
   }
      
    public static boolean isNumber(Character c) {
     if(c == '0' || c == '1' || c == '2' || c == '3' || c == '4'
          || c == '5' || c == '6' || c == '7' || c == '8' || c == '9') {
       return true;
     }
     return false;
   }
    
    public static double evaluate(String str) {
      Stack<Double> myStack = new Stack<Double>();
                   
      for(int i = 0; i < str.length(); i++) {
             Character here = str.charAt(i);
             double result = 0.0;
             
             if(isNumber(here)) {
               double toPush = (double) Character.getNumericValue(here);
               myStack.push(toPush);
             } else if(isOperator(here)) {
               if(myStack.size() < 2) {
                 throw new IllegalArgumentException("Illegal input expression");
               }
               double secondNum = myStack.pop();
               double firstNum = myStack.pop();
               if(here == '+') {
                 result = firstNum + secondNum;
               }
               if(here == '-') {
                 result = firstNum - secondNum;
               }
               if(here == '*') {
                 result = firstNum * secondNum;
               }
               if(here == '/') {
                 if(secondNum == 0) {
                   throw new IllegalArgumentException("Attempt to divide by 0");
                 }
                 result = firstNum / secondNum;
               }
               myStack.push(result);
             } else if(here == ' ') {
                 continue;
             } else {
               throw new IllegalArgumentException("Illegal input expression");
             }
           }
      if(myStack.size() != 1) {
        throw new IllegalArgumentException("Illegal input expression");
      }
      double finalValue = myStack.pop();
      return finalValue;
    }
   
}