// Sarah Yurick (sey13)
public class Example3 {
    public static void main(String[] args) {
        long startTime, stopTime; // For recording start/stop times
        for(int k = 0; k < 10; k++) {
            long x = 0;
            long N = 40000L;
            N += k * 10000;
            startTime = System.currentTimeMillis();
            for (long i = 0; i < N; i++) {
                x = x + 1;
            }
            for (long i = 0; i < N; i++) {
                for (long j = 0; j < N; j++) {
                    x = x + 1;
                }
            }
            stopTime = System.currentTimeMillis();
            long time = stopTime - startTime;
            System.out.println("N = " + N + ", time = " + time + " msec");
        }
    }
}
