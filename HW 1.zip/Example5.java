// Sarah Yurick (sey13)
import java.util.Random;
public class Example5 {
    public static void main(String[] args) {
        Random rand = new Random();
        int N = 50;
        int[] data = new int[N];
        for(int i = 0; i < N; i++) {
            // Adds any number between 0 and N-1
            data[i] = rand.nextInt(N);
        }

        for(int i = 1; i <= 10; i++) {
            int toFind = rand.nextInt(N);
            int location = search(data, toFind);
            System.out.println("Trial #" + i + ", target = " + toFind + ", " + location + " iterations");
        }
    }
    
    public static int search(int[] data, int target) {
        // searches for a given int in an array
        int i; 
        for(i = 0; i < data.length; i++) {
            if(data[i] == target) {
                i++; 
                return i;
            }
        }
        i++;
        return i;
    }
}


