// Sarah Yurick (sey13)
public class Example1 {
    public static void main(String[] args) {
        long startTime, stopTime; // For recording start/stop times
        for(int i = 0; i < 10; i++) {
            int x = 0;
	        long N = 1600000000L;
	        N = N + (i * 100000000);
            startTime = System.currentTimeMillis();
            for (long j = 0; j < N; j++) {
                x = x + 1;
            }
            stopTime = System.currentTimeMillis();
            long time = stopTime - startTime;
            System.out.println("N = " + N + ", time = " + time + " msec");
        }
    }
}
