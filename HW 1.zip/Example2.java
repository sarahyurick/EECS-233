// Sarah Yurick (sey13)
public class Example2 {
    public static void main(String[] args) {
        long startTime, stopTime; // For recording start/stop times
        for(int k = 0; k < 10; k++) {
            int x = 0;
            long N = 40000L;
            N += 10000 * k;
            startTime = System.currentTimeMillis();
            for (long i = 0; i < N; i++) {
                for (long j = 0; j < N; j++) {
                    x = x + 1;
                }
            }
            stopTime = System.currentTimeMillis();
            long time = stopTime - startTime;
            System.out.println("N = " + N + ", time = " + time + " msec");
        }
    }
}
