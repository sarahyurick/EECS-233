// Sarah Yurick (sey13)

import java.util.Random;
import java.util.ArrayList;

public class IntLinkedBag {

    private IntNode head;
    private int manyNodes;

    public IntLinkedBag() {
        head = null;
        manyNodes = 0;
    }
    
    // Part b
    public void add(int element) {
        if(countOccurrences(element) == 0) {
            head = new IntNode(element, head);
            manyNodes++;
        }
    }
    
    public int countOccurrences(int target) {
        int answer;
        IntNode cursor;
        
        answer = 0; 
        cursor = IntNode.listSearch(head, target);
        while(cursor != null) {
            answer++;
            cursor = cursor.getLink();
            cursor = IntNode.listSearch(cursor, target);
        }
        return answer;
    }
    
    // Part c
    public void print() {
        String result = "";
        
        IntNode point = head;
        while(point != null) {
            result += point.getData() + " ";
            point = point.getLink();
        }
        // result += point.getLink();
        
        if(result.equals("")) {
            System.out.println("An empty bag");
        } else {
            System.out.println(result);
        }
    }

    // Part d
    private int get(int index) {
        if(index < 0 || index >= manyNodes) {
            throw new RuntimeException
            ("This index is invalid");
        }
        
        IntNode point = head;
        int counter = 0;
        while(point != null) {
            if(counter == index) {
                break;
            }
            counter++;
            point = point.getLink();
        }
        return point.getData();
    }
    
    // Part e
    public static IntLinkedBag intersection(IntLinkedBag l1, IntLinkedBag l2) {
        // I decided to initially store the values in an ArrayList
        // because I didn't want to deal with the confusion of
        // the "add" method for IntLinkedBag being O(N)
        // and affecting the Big-O notation. 
        ArrayList<Integer> values = new ArrayList<Integer>();        
        for(int i = 0; i < l1.manyNodes; i++) {
            int numToCheck = l1.get(i);
            if(l2.countOccurrences(numToCheck) >= 1) {
                // Note that the "add" method for ArrayLists is O(1). 
                values.add(numToCheck);
            }
        }
            
        IntLinkedBag answer = new IntLinkedBag();
        for(int i = values.size() - 1; i >= 0; i--) {
            // Note that the "get" method for ArrayLists is O(1).
            answer.add(values.get(i));
        }
        return answer;
    }

    // Part a
    public static void main(String[] args) {
        Random rand = new Random();
        
        IntLinkedBag l1 = new IntLinkedBag();
        int num1 = 10;
        // Note that there may be less than num1 items in the bag
        // because using the Randomizer could generate duplicates
        // which are not added to the bag. 
        for(int i = 0; i < num1; i++) {
            int n = rand.nextInt(num1);
            l1.add(n);
        }
        System.out.println("Bag 1: ");
        l1.print();
        int index1 = 1;
        System.out.println("The value of index " + index1 + " is " + l1.get(index1));
        
        System.out.println();
        
        IntLinkedBag l2 = new IntLinkedBag();
        int num2 = 10;
        // Note that there may be less than num2 items in the bag
        // because using the Randomizer could generate duplicates
        // which are not added to the bag.
        for(int i = 0; i < num2; i++) {
            int n = rand.nextInt(num2);
            l2.add(n);
        }
        System.out.println("Bag 2: ");
        l2.print();
        int index2 = 2;
        System.out.println("The value of index " + index2 + " is " + l2.get(index2));
        
        System.out.println();
        
        System.out.println("The intersection of both is: ");
        intersection(l1, l2).print();

    }
}


