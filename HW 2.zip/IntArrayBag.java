// Sarah Yurick (sey13)

import java.util.Random;
import java.util.ArrayList;

public class IntArrayBag {
    
    private int[] data;
    private int manyItems;
    
    public IntArrayBag() {
        final int INITIAL_CAPACITY = 10;
        manyItems = 0;
        data = new int[INITIAL_CAPACITY];
    }
    
    public IntArrayBag(int initialCapacity) {
        if(initialCapacity < 0)
            throw new IllegalArgumentException
            ("The initialCapacity is negative: " + initialCapacity);
        data = new int[initialCapacity];
        manyItems = 0;
   }
   
    
    // Part b
    public void add(int element) {
        if(manyItems == data.length)
        {  // Ensure twice as much space as we need.
            ensureCapacity((manyItems + 1)*2);
        }
        
        if(countOccurrences(element) == 0) {
            data[manyItems] = element;
            manyItems++;
        }
   }
   
    public void ensureCapacity(int minimumCapacity) {
        int[] biggerArray;
    
        if(data.length < minimumCapacity) {
            biggerArray = new int[minimumCapacity];
            System.arraycopy(data, 0, biggerArray, 0, manyItems);
            data = biggerArray;
        }
    }
   
   public int countOccurrences(int target) {
        int answer;
        int index;
      
        answer = 0;
        for(index = 0; index < manyItems; index++) {
            if(target == data[index]) {
                answer++;
            }
        }
        return answer;
   }
   
   // Part c
   public void print() {
       String set = "";
       for(int i = 0; i < manyItems; i++) {
           set += data[i] + " ";
       }
       
       if(set.length() == 0) {
           System.out.println("An empty set");
       } else {
            System.out.println(set);
       }
   }
   
   // Part d
   private int get(int index) {
       if(index < 0 || index >= manyItems) {
           throw new RuntimeException
           ("This index is invalid");
       } else {
           return data[index];
       }
   }
   
    // Part e
    public static IntArrayBag intersection(IntArrayBag b1, IntArrayBag b2) {
        // I decided to initially store the values in an ArrayList
        // because I didn't want to deal with the confusion of
        // the "add" method for IntArrayBag being O(N)
        // and affecting the Big-O notation. 
        ArrayList<Integer> values = new ArrayList<Integer>();        
        for(int i = 0; i < b1.manyItems; i++) {
            int numToCheck = b1.get(i);
            if(b2.countOccurrences(numToCheck) >= 1) {
                // Note that the "add" method for ArrayLists is O(1). 
                values.add(numToCheck);
            }
        }
        
        IntArrayBag answer = new IntArrayBag(0);
        for(int i = 0; i < values.size(); i++) {
            // Note that the "get" method for ArrayLists is O(1).
            answer.add(values.get(i));
        }
        return answer;
   }
   
    public int getCapacity() {
        return data.length;
    }
    
    public static void main(String[] args) {
        Random rand = new Random();
        
        IntArrayBag bag1 = new IntArrayBag(0);
        int num1 = 10;
        // Note that there may be less than num1 items in the bag
        // because using the Randomizer could generate duplicates
        // which are not added to the bag. 
        for(int i = 0; i < num1; i++) {
            int n = rand.nextInt(num1);
            bag1.add(n);
        }
        System.out.println("Bag 1: ");
        bag1.print();
        int index1 = 1;
        System.out.println("The value of index " + index1 + " is " + bag1.get(index1));
        
        System.out.println();
        
        IntArrayBag bag2 = new IntArrayBag(0);
        int num2 = 10;
        // Note that there may be less than num2 items in the bag
        // because using the Randomizer could generate duplicates
        // which are not added to the bag. 
        for(int i = 0; i < num2; i++) {
            int n = rand.nextInt(num2);
            bag2.add(n);
        }
        System.out.println("Bag 2: ");
        bag2.print();
        int index2 = 2;
        System.out.println("The value of index " + index2 + " is " + bag2.get(index2));   
        
        System.out.println();
        
        System.out.println("The intersection of both is:");
        IntArrayBag intersect = intersection(bag1, bag2);
        intersect.print();
    }
}

