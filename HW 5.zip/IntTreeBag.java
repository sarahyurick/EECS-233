// Sarah Yurick
// sey13

// Chris Fietkiewicz. Based on IntTreeBag.java from the package edu.colorado.collections
public class IntTreeBag implements Cloneable
{
   // Invariant of the IntTreeBag class:
   //   1. The elements in the bag are stored in a binary search tree.
   //   2. The instance variable root is a reference to the root of the
   //      binary search tree (or null for an empty tree).
   IntBTNode root = null;   
   
   /**
   * Insert a new element into this bag.
   * @param element
   *   the new element that is being inserted
   * <b>Postcondition:</b>
   *   A new copy of the element has been added to this bag.
   * @exception OutOfMemoryError
   *   Indicates insufficient memory a new IntBTNode.
   **/
   // part a
   public void add(int element)
   {      
      // Implemented by student.
     IntBTNode cursor = root;
     boolean done = false;
     IntBTNode temp = new IntBTNode(element, null, null);
     
     if(root == null) {
       root = temp;
       done = true;
     }

     while(!done) {
       if(element == cursor.getData()) {
         done = true;
       }
       if(element < cursor.getData()) {
         if(cursor.getLeft() == null) {
           cursor.setLeft(temp);
           // temp.setData(element);
           done = true;
         } 
         else {
           cursor = cursor.getLeft();
         }
       } else if(element > cursor.getData()) {
           if(cursor.getRight() == null) {
             cursor.setRight(temp);
             // temp.setData(element);
             done = true;
           }
           else {
             cursor = cursor.getRight();
           }
         }
       }
   }

   /**
   * Remove one copy of a specified element from this bag.
   * @param target
   *   the element to remove from the bag
   * <b>Postcondition:</b>
   *   If <CODE>target</CODE> was found in the bag, then one copy of
   *   <CODE>target</CODE> has been removed and the method returns true. 
   *   Otherwise the bag remains unchanged and the method returns false. 
   **/
   // part b
   private boolean remove(int target)
   {
      // Student will replace this return statement with their own code:
     IntBTNode cursor = root;
     IntBTNode parentOfCursor = null;
     
     while(true) {
       // special case: empty tree
       if(root == null) {
         return false;
       }
       
       if(cursor.getData() == target) {
         if(cursor.getLeft() == null) {
           if(cursor == root) {
             root = root.getRight();
             return true;
           }
           if(cursor == parentOfCursor.getLeft()) {
             parentOfCursor.setLeft(cursor.getRight());
           } else {
             parentOfCursor.setRight(cursor.getRight());
           }
           return true;
         } else {
           cursor.setData(cursor.getLeft().getRightmostData());
           cursor.setLeft(cursor.getLeft().removeRightmost());
           return true;
         }
       } else if(target < cursor.getData()) {
           parentOfCursor = cursor;
           cursor = cursor.getLeft();
       } else {
           parentOfCursor = cursor;
           cursor = cursor.getRight();
       }
     }
   }
   
   // part c
   private void preorderPrint() {
     root.preorderPrint();
   }
   
   // part d
   private void inorderPrint() {
     root.inorderPrint();
   }
   
   // part e
   private void postorderPrint() {
     root.postorderPrint();
   }
   
   // part f
   public static void main(String[] args) {
     IntTreeBag test = new IntTreeBag();
     test.add(6);
     test.add(1);
     test.add(3);
     test.add(2);
     test.add(9);
     test.add(7);
     test.add(5);
     test.add(4);
     test.add(8);
     test.remove(4);
     test.remove(1);
     test.remove(6);
     
     System.out.print("Pre-order: ");
     test.preorderPrint();
     System.out.println();
     System.out.print("In-order: ");
     test.inorderPrint();
     System.out.println();
     System.out.print("Post-order: ");
     test.postorderPrint();
     System.out.println();
   }
   
}
           
