// Sarah Yurick
// sey13

// Chris Fietkiewicz. Incomplete implementation of a priority heap.
// The methods removeMax() and add() do not restore the required heap properties.

public class Heap {
 private int[] data = new int[10]; // Heap data
 private int manyItems = 0; // Quantity of items in the heap
 
 public int removeMax() {
  if (manyItems == 0)
   throw new RuntimeException();
  int maxValue = data[0]; // Get root value
  manyItems--;

  // COMPLETE THIS METHOD TO RESTORE THE REQUIRED HEAP PROPERTIES
  // If the root is the only element in the heap, 
  // then there is really no more work to do
  // except to decrement the instance variable that is keeping track of the size of the heap.
  if(manyItems == 0) {
    return maxValue;
  }

  // The rearrangement begins by moving the last element in the last level up to the root.
  // Copy the last element in the deepest level to the root, 
  // and then take this last node out of the tree. This element is called the "out-of-place" element.
  int outOfPlace = data[manyItems];
  int loc = 0;
  data[loc] = outOfPlace;
  
  // while (the out-of-place element has a priority that is lower than one of its children)
  //   Swap the out-of-place element with its highest-priority child.
  // Return the answer that was saved in Step 1.
  int leftLoc = 1;
  int rightLoc = 2;
  int temp;
  
  while((leftLoc < manyItems) && ((outOfPlace < data[leftLoc]) || (outOfPlace < data[rightLoc]))) {
    // condition where node has only a left child
    if(rightLoc >= manyItems) {
      if(outOfPlace < data[leftLoc]) {
        temp = data[leftLoc];
        data[leftLoc] = outOfPlace;
        data[loc] = temp;
        break;
      }
    // general case where node has 2 children
    }
    if(data[leftLoc] > data[rightLoc]) {
      temp = data[leftLoc];
      data[leftLoc] = outOfPlace;
      data[loc] = temp;
      loc = leftLoc;
      leftLoc = (2 * loc) + 1;
      rightLoc = (2 * loc) + 2;
    } else {
      temp = data[rightLoc];
      data[rightLoc] = outOfPlace;
      data[loc] = temp;
      loc = rightLoc;
      leftLoc = (2 * loc) + 1;
      rightLoc = (2 * loc) + 2;
    }
  }

  print();
  System.out.println();
  return maxValue;
  
 }

 public void add(int element) {
  if (manyItems == data.length)
   ensureCapacity((manyItems + 1) * 2);
  data[manyItems] = element;
  manyItems++;

  // COMPLETE THIS METHOD TO RESTORE THE REQUIRED HEAP PROPERTIES
  // while (the new element has a higher priority than its parent)
  //   Swap the new element with its parent
  int loc = manyItems - 1;
  int parentLoc = (loc - 1) / 2;
  int temp;
  while((loc > 0) && (element > data[parentLoc])) {
    temp = data[parentLoc];
    data[parentLoc] = element;
    data[loc] = temp;
    loc = parentLoc;
    parentLoc = (loc - 1) / 2;
  }
  
  print();
  System.out.println();
 }

 // Print all heap values with array indexes
 public void print() {
  for (int i = 0; i < manyItems; i++)
   System.out.println("[" + i + "] " + data[i]);
 }

 // Taken from ArrayBag.java
 public void ensureCapacity(int minimumCapacity) {
  int[] biggerArray;

  if (data.length < minimumCapacity) {
   biggerArray = new int[minimumCapacity];
   System.arraycopy(data, 0, biggerArray, 0, manyItems);
   data = biggerArray;
  }
 }

 public static void main(String[] args) {
  Heap h = new Heap();
  System.out.println("Adding...");
  System.out.println();
  h.add(1);
  h.add(3);
  h.add(2);
  h.add(4);
  h.add(6);
  h.add(7);
  h.add(8);
  h.add(5);
  System.out.println("Removing...");
  System.out.println();
  h.removeMax();
  h.removeMax();
  h.removeMax();
  h.removeMax();
  h.removeMax();
  h.removeMax();
 }
}
           