// Sarah Yurick
// sey13

// Chris Fietkiewicz
// Based on IntBalancedSet.java from the package edu.colorado.linked and
// described in Section 10.2 of "Data Structures and Other Objects Using Java"

public class IntBalancedSet2
{
   // Invariant of the IntBalancedSet class:
   //   1. The elements of the Set are stored in a B-tree, satisfying the six
   //      B-tree rules.
   //   2. The number of elements in the tree's root is in the instance
   //      variable dataCount, and the number of subtrees of the root is stored
   //      stored in the instance variable childCount.
   //   3. The root's elements are stored in data[0] through data[dataCount-1].
   //   4. If the root has subtrees, then subtree[0] through 
   //      subtree[childCount-1] are references to these subtrees.
   private final int MINIMUM = 1;
   private final int MAXIMUM = 2*MINIMUM;
   int dataCount;
   int[ ] data = new int[MAXIMUM + 1];
   int childCount;
   IntBalancedSet2[ ] subset = new IntBalancedSet2[MAXIMUM + 2]; 

   // Constructor for leaf node (no children)
   public IntBalancedSet2(int[] setData)
   {
     int len = setData.length;
  // Complete this method for Part (a)
     if(len <  MINIMUM || len > MAXIMUM) {
       throw new IllegalArgumentException();
     } else {
       data = setData;
       dataCount = len;
       childCount = 0;
     }
   }

   // Constructor for non-leaf node (has children)
   public IntBalancedSet2(int[] setData, IntBalancedSet2[ ] setSubset)
   {
     int parentLen = setData.length;
     int childRefLen = setSubset.length;
  // Complete this method for Part (b)
     if(parentLen < MINIMUM || parentLen > MAXIMUM || !(parentLen + 1 == childRefLen)) {
       throw new IllegalArgumentException();
     } else {
       data = setData;
       subset = setSubset;
       dataCount = parentLen;
       childCount = childRefLen;
     }
   }
   
   public static void main(String[ ] args)
   {
  // Complete this method for Part (c)
     
     // To make tree from example given
     int[] top = new int[]{6};
     
     int[] middle1 = new int[]{2, 4};
     int[] middle2 = new int[]{9};
     
     int[] bottom1 = new int[]{1};
     int[] bottom2 = new int[]{3};
     int[] bottom3 = new int[]{5};
     int[] bottom4 = new int[]{7, 8};
     int[] bottom5 = new int[]{10};
     
     IntBalancedSet2 child1 = new IntBalancedSet2(bottom1);
     IntBalancedSet2 child2 = new IntBalancedSet2(bottom2);
     IntBalancedSet2 child3 = new IntBalancedSet2(bottom3);
     IntBalancedSet2 child4 = new IntBalancedSet2(bottom4);
     IntBalancedSet2 child5 = new IntBalancedSet2(bottom5);
     IntBalancedSet2[] children1 = new IntBalancedSet2[]{child1, child2, child3};
     IntBalancedSet2[] children2 = new IntBalancedSet2[]{child4, child5};
     
     IntBalancedSet2 parent1 = new IntBalancedSet2(middle1, children1);
     IntBalancedSet2 parent2 = new IntBalancedSet2(middle2, children2);
     IntBalancedSet2[] parents = new IntBalancedSet2[]{parent1, parent2};
     
     IntBalancedSet2 root = new IntBalancedSet2(top, parents);
     
     root.print(0);
     System.out.println();
     
     System.out.println("Root: ");
     if(root.isValid()) {
       System.out.println("Valid");
     } else {
       System.out.println("Not valid");
     }
     
     System.out.println();
     System.out.println("B-tree (checking each node): ");
     if(root.isValid() && parent1.isValid() && parent2.isValid()) {
       System.out.println("Valid");
     } else {
       System.out.println("Not valid");
     }
   }
   
   public boolean isValid()
   {
  // Complete this method for Part (d)
     
     // (1) An element at index i is greater than all the elements in subtree number i of the node
     // (2) an element at index i is less than all the elements in subtree number of the node
     
     if(childCount == 0) {
       return true;
     }
     
     for(int i = 0; i < dataCount; i++) {
       for(int j = 0; j < subset[i].dataCount; j++) {
         if(data[i] < subset[i].data[j]) {
           return false;
         }
       }
       for(int k = 0; k < subset[i + 1].dataCount; k++) {
         if(data[i] > subset[i + 1].data[k]) {
           return false;
         }
       }
     }
       
     return true;

   }
   
   public boolean lessThan(int parentKey)
   {
  // OPTIONAL: Complete this method for Part (d)
     return true;
   }
   
   public boolean greaterThan(int parentKey)
   {
  // OPTIONAL: Complete this method for Part (d)
     return true;
   }
   

   // Print a representation of this set's B-tree, useful during debugging.
   public void print(int indent)
   {
      final int EXTRA_INDENTATION = 4;
      int i;
      int space;
  
      // Print the indentation and the data from this node
      for (space = 0; space < indent; space++)
         System.out.print(" ");
      for (i = 0; i < dataCount; i++)
         System.out.print(data[i] + " ");
      System.out.println( );
         
      // Print the subtrees
      for (i = 0; i < childCount; i++)
         subset[i].print(indent + EXTRA_INDENTATION);
   }
}
