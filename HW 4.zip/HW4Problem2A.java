// Sarah Yurick
// sey13

import java.util.Scanner;
import java.util.Stack;

public class HW4Problem2A {
  
  public static void main(String args[]) {
    Scanner stdin = new Scanner(System.in);
    Stack input = new Stack();
    
    String direction = " ";
    String dirS = "Take a step and remain straight";
    String dirL = "Take a step and turn right";
    String dirR = "Take a step and turn left";
      
    while(!direction.equalsIgnoreCase("q")) {
      System.out.print("Enter a direction for a step (s=straight, l=left, r=right, q=quit): ");
      direction = stdin.nextLine();
      if(direction.equalsIgnoreCase("s")) {
        input.push(dirS);
      } else if(direction.equalsIgnoreCase("l")) {
        input.push(dirL);
      } else if(direction.equalsIgnoreCase("r")) {
        input.push(dirR);
      } else if(!direction.equalsIgnoreCase("q")) {
        System.out.println("Please enter s, l, r, or q");
      }
    }

    System.out.println("Turn 180 degrees");
    while(!input.isEmpty()) {
      System.out.println(input.pop());
    }
    System.out.println("Done!");
  }
}