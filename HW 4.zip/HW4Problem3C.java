// Sarah Yurick
// sey13

public class HW4Problem3C {
  
  public static void main(String args[]) {
    EasyReader stdin = new EasyReader(System.in);
    int n;
    double x;
    
    System.out.println("I can calculate the value of x raised to an integer power.");
    
    do
      {
         x = stdin.doubleQuery("The value of x: ");
         n = stdin.intQuery("The integer power: ");
         System.out.println("Answer: " + pow(x,n));
      }  while (stdin.query("Do you want to try other values?"));   
  }
  
  public static double pow(double x, int n) {
    if(x == 0 && n <= 0)
      throw new IllegalArgumentException("x is zero and n=" + n);
    else if(x == 0)
      return 0;
    else if(n==0)
      return 1;
    else if(n > 0 && n % 2 == 0) {
      double temp = pow(x, n / 2);
      return temp * temp;
    }
    else if(n > 0 && n % 2 != 0)
      return x * pow(x, n - 1);
    else // x is nonzero, and n is negative.
      return 1/pow(x, -n);
  }
  
}
