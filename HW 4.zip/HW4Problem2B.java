// Sarah Yurick
// sey13

import java.util.Scanner;

public class HW4Problem2B {
  
   static String dirS = "Take a step and remain straight";
   static String dirL = "Take a step and turn right";
   static String dirR = "Take a step and turn left";
  
  public static void main(String args[]) {
    directions();
    System.out.println("Done!");
  }
  
  public static void directions() {
    Scanner stdin = new Scanner(System.in);
    System.out.print("Enter a direction for a step (s=straight, l=left, r=right, q=quit): ");
    String direction = stdin.nextLine();
    if(direction.equalsIgnoreCase("s")) {
      directions();
      System.out.println(dirS);
    } else if(direction.equalsIgnoreCase("l")) {
      directions();
      System.out.println(dirL);
    } else if(direction.equalsIgnoreCase("r")) {
      directions();
      System.out.println(dirR);
    } else if(direction.equalsIgnoreCase("q")) {
      System.out.println("Turn 180 degrees");
    } else {
      System.out.println("Please enter s, l, r, or q");
    }
  }
}