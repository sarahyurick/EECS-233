// Sarah Yurick
// sey13

import java.util.Scanner;

public class HW4Problem1 {
  
  public static void main(String[] args) {
    Scanner stdin = new Scanner(System.in);
    System.out.print("What size is the array? ");
    int size = stdin.nextInt();
    
    
    int[] test = new int[size];
    fractal(0, size - 1, test);
    for(int i = 0; i < size; i++) {
      System.out.print(test[i] + " ");
    }
  }
  
  static void fractal(int left, int right, int[] arr) {
    int middle = (left + right) / 2;
    if (left + 1 != right) {
      arr[middle] = right - left;
      fractal(left, middle, arr);
      fractal(middle, right, arr);
    }
  }
}