// Sarah Yurick
// sey13

public class WeightedGraph implements Cloneable
{
   private double[ ][ ] edges;
   private Object[ ] labels;
   
   // part a
   public WeightedGraph(int n)
   {
      edges = new double[n][n];  // All values initially null
      for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
          edges[i][j] = -1.0;
        }
      }
      labels = new Object[n];     // All values initially null
   }
   
   // part b
   public void addEdge(int source, int target, double weight)   
   {
      edges[source][target] = weight;
   }
   
   // part c
   public double getWeight(int source, int target) {
     return edges[source][target];
   }
   
   // part d
   public void printTotalPath(int[] path) {
     double sum = 0.0;
     boolean validPath = true;
     for(int i = 0; i < path.length - 1; i++) {
       if(isEdge(path[i], path[i + 1])) {
         sum += getWeight(path[i], path[i + 1]);
       } else {
         validPath = false;
       }
     }
    
     String line = "The path from ";
     for(int i = 0; i < path.length; i++) {
       line += labels[path[i]] + " ";
       if(i != path.length - 1) {
         line += "to ";
       }
     }
     if(validPath) {
       line += "has a total of " + sum + ".";
     } else {
       line += "is not valid.";
     }
     System.out.println(line);
   }
   
   public Object getLabel(int vertex)
   {
      return labels[vertex];
   }

   public boolean isEdge(int source, int target)
   {
      return (edges[source][target] != -1.0);
   }
              
   public void removeEdge(int source, int target)   
   {
      edges[source][target] = -1.0;
   }

   public void setLabel(int vertex, Object newLabel)
   {
      labels[vertex] = newLabel;
   }   
   
   public int size( )
   {
      return labels.length;
   }
   
   // part e
   public static void main(String[] args) {
     WeightedGraph g = new WeightedGraph(4);
     g.addEdge(0, 1, 1.5);
     g.addEdge(1, 2, 2.2);
     g.addEdge(2, 3, 1.4);
     g.addEdge(3, 0, 3.9);
     
     g.setLabel(0, "Byteville");
     g.setLabel(1, "Bitburg");
     g.setLabel(2, "Nulltown");
     g.setLabel(3, "Binaria");
     
     int[] p1 = {1, 2, 3};
     int[] p2 = {0, 2, 3};
     
     g.printTotalPath(p1);
     g.printTotalPath(p2);
   }
        
}
           
